############################################################################
## gMetapop - Test 5.2 - prog to run from the GUI File/Custom plot option ##
############################################################################
# Pauline Garnier-G�r� & Fr�d�ric Austerlitz Jan 2019

# Test for strong Selection on genotypes - plot for recessive model, see 5.5.2 in User Manual
# of allele frequency trajectories (advantageous + neutral alleles (1 to 9))
# Usage example: File Menu in the GUI, option "Custom plot" then type command
# test5.2.plotFreq.r res1_freq_1.txt test5.2.p0.01.3000-nomut-run1 0.0001 600
                     # res1_freq_1.txt (first argument needs to be the output frequency file given by gMetapop,compulsory in Custom plot)
                     # test5.2.p0.01.3000-nomut-run1 (second argument is the plot.name can be changed, if none given, NA.png plot produced, no extension needed)
                     #  0.0001 (is the theoretical average initial allele frequency at loci under selection, additional argument in the script)
                     #  600    (is the nb of generations, for visualizing only part of the simulations , optional argument)
# --> see gMetapop User Manual 3.9.2 for more explanations on custom plots
# this command line can be used outside the GUI
# The legends in the plot below corresponds to 10% maximum difference between genotypes' fitness, and can be changed
# WARNING this script also uses the conf.txt file corresponding to simulations, 

require(plyr)
# Define arguments for launching the Rscript from command line
cmd_args <- commandArgs(trailingOnly = TRUE)
result.file<-cmd_args[1]
plot.name<-cmd_args[2]
ini.sel.al.freq<-cmd_args[3]
nb.of.gen.on.plot<-cmd_args[4]

# Import gMetapop allele frequencies result file
res<-read.table(file=result.file, header=T,sep=";",strip.white=T, fill=T)

### Get selected loci from conf.txt
conf <- scan(file="conf.txt",what=character(0), sep="\n", quiet=TRUE)
extract.conf.num.last<-function(x) as.numeric( strsplit(x,split=" ")[[1]][length(strsplit(x,split=" ")[[1]])] )
extract.conf.char<-function(x)  strsplit(x,split=" ")[[1]][length(strsplit(x,split=" ")[[1]])]
nb.pop<-extract.conf.num.last(conf[3])
## extract nb of loci under selection and their allele nb
 if (extract.conf.char(grep('Kind of sel', conf, value=TRUE))!="n") {
    seline<-grep('Selected nuclear', conf, value=TRUE)
    selloc<-as.numeric(strsplit( strsplit(seline,split=":")[[1]][2] , split=" ")[[1]])
    selloc.nona<- selloc[which(is.na(selloc)==F)]
    nb.sel<-sum( selloc.nona)

    # extract data frame or matrix with selected alleles a2 under positive selection here
    col.a2<-grep("a2",colnames(res), value=TRUE)
    res.a2<-res[,c("Generation","Pop",col.a2)]
    res.a2.sel<-res.a2[,c("Generation","Pop",colnames(res.a2)[which(selloc.nona==1)+2]) ]

    # extract data frame with neutral alleles
      lneu.nb<-paste("l",which(selloc.nona==0),"a",sep="")
      allneu.nb<-NULL
      for (i in 1:length(lneu.nb) ) {
      lneu.al<-grep(lneu.nb[i],names(res)) ;  allneu.nb<-c(allneu.nb,lneu.al)
      }
     res.neu1<-res[,c("Generation","Pop",names(res)[allneu.nb])] # names(res.neu)
     res.neu<-res.neu1[,-which(names(res.neu1) %in% grep("a10",colnames(res.neu1), value=TRUE))]  #  removing 10th alleles at each neutral locus
 }

### Opening  png plot device --> png file processed by GUI afterwards
 png(filename=paste(plot.name,".png",sep=""),unit = "cm", width = 17, height = 15 , res = 300)
# pdf(file=paste(plot.name,".pdf",sep=""))  # pdf(file="fig.pdf", width = 7, height = 6 )

###############################
## Plot all allele trajectories
ylim.maxbound<-1 
ylim.minbound<-0 

if (is.na(nb.of.gen.on.plot)==T) nbgen<-max(res$Generation) else nbgen<-as.numeric(nb.of.gen.on.plot)

if (length(names(res.neu))!=0 ) {
al1 <-colnames(res.neu)[3]
plot(res.neu$Generation[which(res.neu$Pop==1)],res.neu[which(res.neu$Pop==1),al1], col = "lightgrey", ylab="allele frequency changes", xlab="Generations", ylim=c(ylim.minbound,ylim.maxbound),
  xlim=c(0,nbgen), type = "l" )  # one pop, one locus
# other loci, only 1 pop ( more can be added), still 10 cod1 loci /replicates --> enough lines representative of neutral evolution in plot
  for (al in colnames(res.neu)[-c(1,2)]) {
#  for (i in 1:nb.pop) {
   lines(res.neu$Generation[which(res.neu$Pop==1)],res.neu[which(res.neu$Pop==1),al], col="lightgrey", lwd = 1 )
#  }
  }
}

### plot of loci in res.sel (loci under selection)
res.sel<-res.a2.sel # res.sel if the allele freq matrix for a2 the allele under positive selection, see above
for (loc in colnames(res.sel)[-c(1,2)][1:10]) { #First 10 selected loci, same fitness values across 5 pop,
  for (i in 1:5) {
   lines(res.sel$Generation[which(res.sel$Pop==i)],res.sel[which(res.sel$Pop==i),loc], col="green", lwd = 1.5 )
  }
}

### Adding Theoretical case
ngen = nbgen
valres = matrix(0,ngen+1,4)
p0=ini.sel.al.freq    #ini.sel.al.freq <-0.00001
s = 0.1  # 10% max fitness differences between genotypes
w11 = 1
w12 = c(1-s/2,1,1-s) # in turn additive , dominant & recessive case as in simulations
w22 = 1-s

valres[1,]=c(0,as.numeric(p0),as.numeric(p0),as.numeric(p0))

for (gen in 2:(ngen+1)) {  #gen<-2
	valres[gen,1]=gen-1
	for (typ in 1:3) { #typ<-3 typ is type of heterozygote (ie defines the scenarios)
		p = valres[gen-1,typ+1] # initial pop freq of A selected allele
		q = 1-p
		w1 = p*w11 + q*w12[typ] # fitness of Ax genotypes --> A allele
		w = p*p*w11 + 2*p*q*w12[typ] + q*q*w22  # fitness total pop
		valres[gen,typ+1] = p*w1/w  # new frequency of A allele based on its relative fitness
	}
}
# plotting only recessive scenario
#lines(valres[,1],valres[,2], col="darkred", lwd=4, lty=2)
#lines(valres[,1],valres[,3], col = "cyan", lwd=4, lty=2)
lines(valres[,1],valres[,4], col = "darkgreen", lwd=4, lty=2)

legend("bottomright", lwd=c(2,4,3),lty=c(1,2,1), legend=c("recessive 10%","recessive (theory)","neutral"),
col=c("green","darkgreen","lightgrey"),inset=0.05,bg="white",box.lty=0) # bty="n"
dev.off()