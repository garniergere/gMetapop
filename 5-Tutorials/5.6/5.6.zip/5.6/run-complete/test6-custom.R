#######################################################################
## gMetapop - Test 6 - script to run from the GUI Custom plot option ##
#######################################################################
# script for plotting equation 5.23 & 5.24 p. 250 Ch 5 Hartl & Clark  2006
# Pauline Garnier-G�r� Nov 2019

## --> Usage: please type in the File/Custom plot window from the GUI :
##     test6-custom.R res1_freq_1.txt test6 50 # the first argument is always a result file from the working folder (indicated in the Run Tab)
                                               # in this script it is the allele frequency result file 
                                               # the second argument "test6" can be changed, it is the plot name (no extension required)
                                               # 50 is the number of replicates (can be changed depending on the run)
require(plyr)
## Arguments definition
cmd_args <- commandArgs(trailingOnly = TRUE)
result.file<-cmd_args[1] # result.file<-"res1_freq_1.txt" define argument 1 as the res per gen filename
plot.name<-cmd_args[2] # plot.name<-"cust6" second arg for custom plot is always the name for the png plot opened via the GUI
                       # see png() below = compulsory line for the GUI to manage the plot.
rep.nb<-cmd_args[3]    # rep.nb<-50 or replicates as one argument
                       # additional arguments can be designed by the user for a similar plot
gen.nb<-2000
pop.nb<-13     # nb of populations corresponding to a # level of selection
coef.sel<-c(seq(-4,2,0.5))  # 4Ns value corresponding to each of the 13 pop
loc.nb<-1000

# Import gMetapop allele frequencies result file and count fixation events
res<-read.table(file=result.file, header=T,sep=";",strip.white=T, fill=T)
# delete col with 2nd allele in res
col.first.al<-grep("a1",colnames(res), value=TRUE)
res2<-res[which(res$Generation==gen.nb),c("Pop",col.first.al)]
# cbind col with population coefficients of selection
prob.fix.1<-c(rep(0,13))    # initializing vector of fixation proba for first replicate
res3<-cbind(coef.sel,prob.fix.1,res2)
  for (i in 1:pop.nb) {
  res3[i,"prob.fix.1"]<-sum(res3[which(res3$Pop==i),-c(1:3)]==0)*2/10 # factor due to y= proba.fix (/100)* 2*N(=100)
  res4<-res3[,-c(4:(loc.nb+3))]
  }

# Loop across the 49 other replicates , each prob.fix is the fixation probability of the alternative allele across loci

for (re in 2:rep.nb) { #re<-2
  resu<-read.table(file=paste("res",re,"_freq_1.txt",sep=""), header=T,sep=";",strip.white=T, fill=T)
  resu2<-resu[which(resu$Generation==gen.nb),c("Pop",col.first.al)]
  resu3<-cbind(prob.fix.1,resu2)
  for (i in 1:pop.nb) {
  resu3[i,1]<-sum(resu3[which(resu3$Pop==i),-c(1:2)]==0)*2/10
  colnames(resu3)[1]<-paste("prob.fix.",re,sep="")
  resu4<-resu3[,-c(3:(loc.nb+2))]
  }
  res4<-merge(res4,resu4,by.x="Pop",by.y="Pop",sort=T)
}

## proba that a mutant allele with freq p will ultimately be fixed in one pop with a particular starting freq, here 0.03
fixation.proba <- function(U,start.freq=0.03) ((1-exp(-U*start.freq))/(1-exp(-U)))*200
                                                             # for p=0.03 with 200 being for *1/2N, scaling for N=100

## Opening  png plot device --> png file processed by gMetapop GUI afterwards
png(filename=paste(plot.name,".png",sep=""),unit = "cm", width = 14, height = 14 , res = 200)
# pdf(file="t8.cusplot.pdf", width = 7, height = 6 )

## plot theoretical curves
plot (fixation.proba, from=-4, to=2 ,xlab="4Ns for N=100",ylim=c(0,max(res4[,-c(1,2)])),col="black",lwd=2)
  # max(res4[,-c(1,2)]) defines the plot y-axis upper limit
abline(v=0,  lwd=2)
## --> with S=4Ns, adding another theoretical curve on the same plot
fun1<-function(S) ((2*(S/(4*100)))/(1-exp(-S)))*200  # 200 is for *1/2N for scaling for N=100
plot (fun1, from=-4, to=2 ,col="red",lwd=2, add=TRUE)

## plot simulated data
# computing mean across replicates
m.prob<-apply(res4[,-c(1,2)],1,mean,na.rm = TRUE) ; resf<-cbind(m.prob,res4) # computing mean fixation proba

# add replicated values across 1000 loci accounting for weight of observing similar values
 cl <- colors()
 for (p in 1:pop.nb) { # p<-10
      sel.p<-as.data.frame(table(as.numeric(resf[p,-c(1,2,3)])))
      plotcol<- rainbow(length(sel.p$Var1))
      for (i in 1:length(sel.p$Var1) ) { # i<-1
         c.i<-plotcol[i]
         prob.fix.i<-as.numeric(as.vector(sel.p$Var1[i]))
         if (resf[p,"coef.sel"]<(-1))  {cex.i=(0.3*as.numeric(sel.p$Freq[i]))/2
         } else cex.i=(0.4*as.numeric(sel.p$Freq[i]))
         points(resf[p,"coef.sel"],prob.fix.i, col=c.i,lwd=3,pch=16,cex=cex.i)
      }
 }
# adding mean across replicates (i.e. loci here) - with big squares
points(resf$coef.sel,resf$m.prob, col="black",lwd=3,pch=15,cex=0.8)

dev.off()
