###########################
## gMetapop - Test 5.2.1 ##
###########################
# script for plotting the evolution of allele frequencies in scenarios with reversible mutation rate
# possible to launch as Custom Plot in the GUI
# see gMetapop User Manual 5.2.1
# PGG  Feb 2017

# Simulation of 2 pop (with opposite fixed initial frequencies), 50 loci, every 10 generations 
# same mutation parameter (coefficient) per locus
# 2 cases:
# 1) mu=0.00001, Ne=100000, Poisson mutation model 
# 2) mu=0.00005, Ne=20000, Poisson mutation model 

# Define arguments for launching the Rscript from command line
cmd_args <- commandArgs(trailingOnly = TRUE)
result.file<-cmd_args[1] # result.file<-"res1_freq_1.txt" define argument 1 as the res per gen filename
plot.name<-cmd_args[2] # plot.name<-"test2.1" second arg for custom plot is always the name for the *.png plot opened via the GUI
                       # see png() below = compulsory line for the GUI to manage the plot. Otherwise the plot might be in the working folder but
                       # not visible via the GUI.
# In order to plot both scenario 1 and 2, launch the script from the run-complete-sce2 working folder
# WARNING: you will have to change the path to the scenario 1 res1_freq_1.txt file below according to your own folder organization
# Command line example to use in the Command line window (which is opened with File menu/Custom plot in the GUI)
# test2.1.custom.plot.R res1_freq_1.txt test2.1

### Theoretical curve points
eq.sce = function(mu,last,p0){  # p0 = initial frequency, mu= mutation rate , last: time|nb of gen
          p.pop1= numeric(last)
          p.pop1[1]=p0
          for (ti in 2:last) p.pop1[ti] = mu*(1-2*p.pop1[ti-1])+p.pop1[ti-1]  
          # recurrence formula for p(t) =p(t-1)*(1-mu1)+(1-p(t-1))*nu1 for nu1=mu1 (cf 3.1 page 111 Hartl and Clarck)
          return(p.pop1)
          }

lastgen<-50000  ; mu2<-0.00005 ; mu1<-0.00001
theo.sce<-cbind( seq(0,lastgen-1,by=1),eq.sce(mu2,lastgen,1),
eq.sce(mu2,lastgen,0),eq.sce(mu1,lastgen,1),eq.sce(mu1,lastgen,0) )
colnames(theo.sce)<-c("Gen","sce2.pop1","sce2.pop2","sce1.pop1","sce1.pop2")

##############################################
# import "res1_freq_1.txt" from sce 2  then sce 1

f.sce2<-read.table(file=result.file, header=T,sep=";",strip.white=T, fill=T)  
fa1.sce2<-f.sce2[,-c(seq(4,202,by=2))]  # remove second allele    tail(mf.p1.p2.sce2)
f.pop1.sce2<-fa1.sce2[which(fa1.sce2$Pop==1),]
f.pop2.sce2<-fa1.sce2[which(fa1.sce2$Pop==2),]
mf.p1.sce2<-cbind( f.pop1.sce2[,1],colMeans(t(f.pop1.sce2[,-c(1:2)])) )
colnames(mf.p1.sce2)<-c("Gen","mf.pop1")
mf.p2.sce2<-cbind( f.pop2.sce2[,1],colMeans(t(f.pop2.sce2[,-c(1:2)])) )
colnames(mf.p2.sce2)<-c("Gen","mf.pop2")
mf.p1.p2.sce2<-merge(mf.p1.sce2,mf.p2.sce2,by.x="Gen",by.y="Gen",sort=T)

f.sce1<-read.table(file=paste('C:\\gM_1.0.0\\5.2.1\\run-complete-sce1\\',result.file,sep=""), header=T,sep=";",strip.white=T, fill=T) 
fa1.sce1<-f.sce1[,-c(seq(4,202,by=2))]  # remove second allele      
f.pop1.sce1<-fa1.sce1[which(fa1.sce2$Pop==1),]
f.pop2.sce1<-fa1.sce1[which(fa1.sce2$Pop==2),]
mf.p1.sce1<-cbind( f.pop1.sce1[,1],colMeans(t(f.pop1.sce1[,-c(1:2)])) )
colnames(mf.p1.sce1)<-c("Gen","mf.pop1")
mf.p2.sce1<-cbind( f.pop2.sce1[,1],colMeans(t(f.pop2.sce1[,-c(1:2)])) )
colnames(mf.p2.sce1)<-c("Gen","mf.pop2")
mf.p1.p2.sce1<-merge(mf.p1.sce1,mf.p2.sce1,by.x="Gen",by.y="Gen",sort=T)

mf.p1.p2<-merge(mf.p1.p2.sce2,mf.p1.p2.sce1,by.x="Gen",by.y="Gen",sort=T)

# Opening  png plot device --> png file processed by gMetapop GUI afterwards
    png(filename=paste(plot.name,".png",sep=""),unit = "cm", width = 20, height = 18 , res = 600)  

# Plotting theoretical curves
plot(theo.sce[,"Gen"],theo.sce[,"sce2.pop1"],col="black",pch=16,cex=0.5, xlab="Generation",
      ylab="Allele frequency",xlim=c(0,lastgen),ylim=c(0.0,1.0))
points(theo.sce[,"Gen"],theo.sce[,"sce2.pop2"], col="black",pch=16,cex=0.5)
points(theo.sce[,"Gen"],theo.sce[,"sce1.pop1"], col="grey",pch=16,cex=0.5)
points(theo.sce[,"Gen"],theo.sce[,"sce1.pop2"], col="grey",pch=16,cex=0.5)
# plot of mean across 100 loci at each stepyear 
points(mf.p1.p2[,"Gen"],mf.p1.p2[,"mf.pop1.x"],col="blue",pch=16,cex=0.4)
points(mf.p1.p2[,"Gen"],mf.p1.p2[,"mf.pop2.x"],col="red",pch=16,cex=0.4)
points(mf.p1.p2[,"Gen"],mf.p1.p2[,"mf.pop1.y"],col="blue",pch=16,cex=0.4)
points(mf.p1.p2[,"Gen"],mf.p1.p2[,"mf.pop2.y"],col="red",pch=16,cex=0.4)

#savePlot(filename=paste("test2.1.jpg"),type="tiff")

# Plot of some loci trajectories across generations for scenario 2 and one initial allele frequency
cl<-colours()
plotcol50<-cl[c(24,32,68,81,254,100,82,382,490,552,536,498,541,547,24,32,68,81,82,
                 100,254,382,490,552,498,536,541,547,24,32,68,81,82,100,254,382,490,
                 552,498,536,541,547,24,32,68,81,82,100,254,382)]

seqloc<-c(1,2,3,4,5)                                          
for (i in seqloc) {          # for the 5 loci selected for the plot
        c.i<-plotcol50[i]     # for each color among the numbers selected in plotcol50, same colour for "p1" and "p0"
        points(f.pop1.sce2[,1],f.pop1.sce2[,(i+1)],col=c.i,lwd=3,pch=16,cex=0.1)
    #    points(f.pop2.sce2[,1],f.pop2.sce2[,(i+1)],col=c.i,lwd=3,pch=16,cex=0.05)
}

#savePlot(filename=paste("test2.1+5loci.jpg"),type="tiff")
dev.off()
