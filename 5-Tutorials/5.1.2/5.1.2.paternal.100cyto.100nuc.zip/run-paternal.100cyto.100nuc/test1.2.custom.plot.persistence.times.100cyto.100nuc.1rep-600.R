############################################
## gMetapop- Test 5.1.2
############################################
# see gMetapop User Manual Chapter 5 Test 5.1.2
# adapted custom plot script for plotting persistence times using both diploid and haploid loci in a drift scenario.
# see User Manual 3.9.2 for more information in Custom plots
# Pauline Garnier-G�r� June 2020

require(plyr)
cmd_args <- commandArgs(trailingOnly = TRUE)
result.file<-cmd_args[1] # result.file<-"res1_freq_1.txt" define argument 1 as the res per gen filename
plot.name<-cmd_args[2] # plot.name<-"custom.test1" for example, the second arg for custom plot is always the name for the png plot opened via the GUI
                       # see png() below = compulsory line for the GUI to manage the plot. Otherwise the plot might be in the working folder but
                       # not visible via the GUI.
# Command line example to use in the Command line window (which is opened with File menu/Custom plot in the GUI)
# test1.2.custom.plot.persistence.100cyto.100nuc.1rep-600.R res1_freq_1.txt test1.2.paternal-100cyto.100nuc.1rep.600 



nbloc = 100  # for both nuclear + cytos loci

# Import gMetapop allele frequencies result files
res<-read.table(file=result.file, header=T,sep=";",strip.white=T, fill=T)  # few min to process > 400 Mb file

# delete col with 2nd allele in res
col.first.al<-grep("a1",colnames(res), value=TRUE)

### Extract nuclear loci & cyto loci files and fixation times separately, and merge the plots

newdon.nuc<-res[,c("Generation","Pop",col.first.al)][,1:(nbloc+2)]
newdon.cyt<-res[,c("Generation","Pop",col.first.al)][,c(1,2,(nbloc+3):(2*nbloc+2))]
# newdon.XXX are the file with only the first allele frequency across loci

nbpop<-40      # nb of populations starting with a # initial allele frequency

# Import population intial frequencies popfinit2.txt for 50 loci, 40 pop
popfinit2<-read.table(file="popfinit2.txt", header=F,sep="\t",dec=".",strip.white=T)
colnames(popfinit2)<-c("pop","initf")

## filling matrix for fixation times for nuclear loci
fixtime.simul<-matrix(NA,nbpop,nbloc)
locfixlist<-NULL
for (i in 1:nbloc) {
  locfixlist<-c(locfixlist,paste("locfix",i,sep=""))
  }
colnames(fixtime.simul)<-locfixlist
# merging with popfinit2 with 40 pop and 50 loci
fixtime.sim<-cbind(popfinit2,fixtime.simul); fixtime.sim<-as.matrix(fixtime.sim)

 for (i in 1:nbloc) { # loop on loci  i<-25
   for (p in 1:nbpop) { # loop across pop (i.e. one initial allele frequency value)  p<-20
      fix.i.pop.p<-newdon.nuc[which(newdon.nuc[,2]==p),c(1,2+i)] # extracting all p pop data    dim(fix.p.pop)    # head(fix.i.pop.p)
      fixtime.sim[p,2+i]<-min(rbind(fix.i.pop.p[which(fix.i.pop.p[,2]==0),],fix.i.pop.p[which(fix.i.pop.p[,2]==1),])[,1]) # min of Generation times where allele fixed
      if (length(fixtime.sim[p,2+i])==0) fixtime.sim[p,2+i]<-NA
      if (is.infinite(fixtime.sim[p,2+i])==T) fixtime.sim[p,2+i]<-NA
   }
 }
fixtime.sim.nuc<-fixtime.sim
maxfix<- aaply(fixtime.sim.nuc[,-c(1:2)],1,function(x) max(x,na.rm=T)) # search for max across each row vector (initial allele freq),
quan50<-quantile(maxfix,probs=0.50,na.rm=T)
#     0%     25%     50%     75%    100%
#  61.00  731.75  895.00 1386.00 9059.00

## filling matrix for fixation times for cytos loci
fixtime.simul<-matrix(NA,nbpop,nbloc)
locfixlist<-NULL
for (i in 1:nbloc) {
  locfixlist<-c(locfixlist,paste("cytfix",i,sep=""))
  }
colnames(fixtime.simul)<-locfixlist
# merging with popfinit2 with 40 pop and 50 loci
fixtime.sim<-cbind(popfinit2,fixtime.simul); fixtime.sim<-as.matrix(fixtime.sim)

 for (i in 1:nbloc) { # loop on loci  i<-25
   for (p in 1:nbpop) { # loop across pop (i.e. one initial allele frequency value)  p<-20
      fix.i.pop.p<-newdon.cyt[which(newdon.cyt[,2]==p),c(1,2+i)] # extracting all p pop data    dim(fix.p.pop)    # head(fix.i.pop.p)
      fixtime.sim[p,2+i]<-min(rbind(fix.i.pop.p[which(fix.i.pop.p[,2]==0),],fix.i.pop.p[which(fix.i.pop.p[,2]==1),])[,1]) # min of Generation times where allele fixed
      if (length(fixtime.sim[p,2+i])==0) fixtime.sim[p,2+i]<-NA
      if (is.infinite(fixtime.sim[p,2+i])==T) fixtime.sim[p,2+i]<-NA
   }
 }
 fixtime.sim.cyt<-fixtime.sim
#maxfix<- aaply(fixtime.sim[,-c(1:2)],1,function(x) max(x,na.rm=T)) # search for max across each row vector (initial allele freq),
#quan90<-quantile(maxfix,probs=0.90,na.rm=T)
#     0%     25%     50%     75%    100%
#  61.00  731.75  895.00 1386.00 9059.00


## Opening  png plot device --> png file processed by gMetapop GUI afterwards
png(filename=paste(plot.name,".png",sep=""),unit = "cm", width = 20, height = 18 , res = 600)  # next version gM

### Plot of nuclear loci persistence times
Ne<-100 ; p0<-data.frame(seq(0,1,0.0001))
fixtim<-function(N,p) {
 fixt<-(-4*N*((1-p)*log(1-p)+p*log(p)));  return(fixt)     # Theoretical curves data  for diploid loci
}
curve.fix<-data.frame(p0,fixtim(Ne,p0)); colnames(curve.fix)<-c("p0","fixt")

plot(curve.fix$p0,curve.fix$fixt, col="blue",pch=16,cex=0.1, xlab="Initial frequency",
                          ylab="Persistence times acros loci (nuclear in blue/cyan - cytoplasmic in red/orange)",xlim=c(0.0,1.0),ylim=c(0.0,600)) #round(quan50,0)) )
# Completing  theoretical curve  with simulated data
fixtime<-as.data.frame(fixtime.sim.nuc) #names(fixtime.sim)
meanfix<-apply(fixtime[,-c(1,2)],1,mean,na.rm = TRUE); fixtimef<-cbind(fixtime,meanfix) # compute and merge mean across loci
# adding means across loci (big squares)
points(fixtimef$initf,fixtimef$meanfix, col="blue",lwd=3,pch=15,cex=0.8)
#adding all individual replicate loci
for (i in 1:nbloc) {
         locfix.i<-fixtimef[,i+2]
         points(fixtimef$initf,locfix.i, col="cyan",lwd=3,pch=16,cex=0.4)
        }

### Adding cytos loci persistence times
Ne<-100 ; p0<-data.frame(seq(0,1,0.0001))
fixtim.cy<-function(N,p) {
 fixt<-(-2*N*((1-p)*log(1-p)+p*log(p)));  return(fixt)     # Theoretical curves data  for haploid loci
}
curve.fix.cy<-data.frame(p0,fixtim.cy(Ne,p0)); colnames(curve.fix.cy)<-c("p0","fixt")

lines(curve.fix.cy$p0,curve.fix.cy$fixt, col="red", lwd=2,lty=1 )
# Completing  theoretical curve  with simulated data
fixtime<-as.data.frame(fixtime.sim.cyt) #names(fixtime.sim)
meanfix<-apply(fixtime[,-c(1,2)],1,mean,na.rm = TRUE); fixtimef<-cbind(fixtime,meanfix) # compute and merge mean across loci
# adding means across loci (big squares)
points(fixtimef$initf,fixtimef$meanfix, col="red",lwd=3,pch=15,cex=0.8)
#adding all individual replicate loci

for (i in 1:nbloc) {
         locfix.i<-fixtimef[,i+2]
         points(fixtimef$initf,locfix.i, col="orange",lwd=3,pch=16,cex=0.4)
        }

dev.off()
