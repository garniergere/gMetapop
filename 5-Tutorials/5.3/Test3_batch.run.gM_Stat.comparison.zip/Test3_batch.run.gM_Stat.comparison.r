#########################################################################
## gMetapop TESTs 5.3 Pauline Garnier-G�r� & St�phanie Mariette
## Last updated 22/10/21

## A) Modify the migration matrices across a set of conf.txt ()configuration) files in a range of scenarios
##    created by the Multiple conf option (Run Tab)
## B) Run gMetapop in batch from R (or from the GUI, cf NB.5.3-a in the User Manual for more information)
## C) Differentiation statistics estimation from R and comparison with gMetapop estimates & Correlations among statistics
## D) Plot of results

## NB: this script can easily be adapted to run a series of scenarios where parameters (other than migration rates) vary
##  across a range of different values

## The next 4 lines are generic, to update according to each user file organization for exe folders 
exe.path.win<-"C:\\0-21-10-14-gM\\gMetapop_1311_1303_Win64"
exe.path.lin<-"put.path.from.linux.OS.here"
gM.core.win<-"gMetapop_CORE_Win64.exe"
gM.core.lin<-"gMetapop_CORE_Linux64"

## The next 4 lines are specific to reproducing the different steps of the tests 3 tutorial
start.of.wdir.path<-"C:/gM_1.0.0/5.3/Ex-multiple-conf-xd-NB5.3-a"   # start of the working path either in linux of windows OS
vec.2.vary<-c(seq(0,0.0008,0.0001),seq(0.001,0.002,0.0002),seq(0.0025,0.005,0.0005)) # vec of values generating changes for parameters in the conf.txt files
nb.conf<-21                  # number of configuration files produced with the "Multiple conf" option of the Run Tab
dem.nb<-2                   # or change it to 50 , for the 50 demes case

##########################################################################################################
install.packages("stringr")
library("stringr")
end.of.wdir.path<-paste("/5.3_",dem.nb,"d",sep="")     
wdir<-paste(start.of.wdir.path,end.of.wdir.path,sep="")
setwd(wdir)
extract.num.last<-function(x) as.numeric( strsplit(x,split=" ")[[1]][length(strsplit(x,split=" ")[[1]])] )
extract.char<-function(x)  strsplit(x,split=" ")[[1]][length(strsplit(x,split=" ")[[1]])]

##  A) Modify the values in the zygote migration matrices across configuration conf.txt files in a range of scenarios
##     part of script (until ##B) specific to modifying zygote migration rates, can easily be adapted to modifying 
##     in batch other parameters or parts of the conf.txt files    
vec.mig<-vec.2.vary
for (r in 1:nb.conf) { #r<-3
  conf <- scan(file=paste(wdir,"/simu",r,"/conf.txt",sep=""),what=character(0), sep="\n", quiet=TRUE)
  nb.pop<-extract.num.last( grep('Number of populations',conf, value=TRUE) )      
  pop.zyg<-conf[(grep('Seed flow matrix',conf)+1) : (grep('Mutation rate of each nuc',conf)-1)] #grep used here with default value=F for indices, needs brackets
  if (length(grep("\t",pop.zyg[1]))!=0) {
      pop.zyg2<-apply(as.matrix(pop.zyg),1,function(x) as.numeric(strsplit(x,split="\t")[[1]]))
     } else pop.zyg2<-apply(as.matrix(pop.zyg,col=length(pop.zyg)/2),1,function(x) as.numeric(strsplit(x,split=" ")[[1]]))                                       
  pop.zyg2[,]<-vec.mig[r]/(nb.pop-1)
  diag(pop.zyg2)<-1-vec.mig[r]
  write.table(conf[1:(grep('Seed flow matrix',conf))],paste(wdir,"/simu",r,"/conf.txt",sep=""),quote=FALSE,col.names=FALSE,row.names=FALSE)
  write.table(pop.zyg2,paste(wdir,"/simu",r,"/conf.txt",sep=""),append=TRUE,quote=FALSE,col.names=FALSE,row.names=FALSE)
  write.table(conf[grep('Mutation rate of each nuc',conf):length(conf)],paste(wdir,"/simu",r,"/conf.txt",sep=""),append=TRUE,quote=FALSE,col.names=FALSE,row.names=FALSE)
}

##  B) Run gMetapop for the multiple conf option 
##  B1) Either from the GUI after running #A)
##  B2) or under a windows or linux OS, create a *.bat (paths including either backslash, combination of backslash & slash or slash only)
##      and run them
 if( .Platform$OS.type == "windows" ) {
  write.table("@echo off","run_gMetapopCore.bat",quote=FALSE,col.names=FALSE,row.names=FALSE)
  write.table(paste("SET PATH=%PATH%;",exe.path.win,'\\dll4TheCore\\',sep=""), "run_gMetapopCore.bat",append=TRUE,quote=FALSE,col.names=FALSE,row.names=FALSE) 
  for (r in 1:nb.conf) {
  write.table(paste(exe.path.win,'\\',gM.core.win," -C ",'simu',r,'\\conf.txt'," -D ","type.txt"," -R ",'simu',r,'\\res1'," -W ",wdir,"/",sep=""),"run_gMetapopCore.bat",append=TRUE,quote=F,col.names=FALSE,row.names=FALSE)
  }
 system("run_gMetapopCore.bat") # alternatively, comment this line out and just run *.bat file from the Command prompt in Windows
 }

 if( .Platform$OS.type == "unix" ) {
  write.table("#! /bin/sh","run_gMetapopCore.sh",quote=FALSE,col.names=FALSE,row.names=FALSE)
  for (r in 1:nb.conf) {
  write.table(paste(exe.path.lin,"/",gM.core.lin," -C ","simu",r,"/","conf.txt"," -D ","type.txt"," -R ","simu",r,"/","res1"," -W ",wdir,"/",sep=""),
  "run_gMetapopCore.sh",append=TRUE,quote=FALSE,col.names=FALSE,row.names=FALSE)
  }
 system("sh run_gMetapopCore.sh") # alternatively, comment this line out and just run the *.sh file from the Command prompt under linux 
 }

## C)
library(diveRsity)
N<-1000
mu<-0.000001
#########################################################
resxd<-matrix(nrow=nb.conf,ncol=7)
colnames(resxd)<-c("m",paste("Gst-",dem.nb,"d-mean",sep=""),paste("Gstcor-",dem.nb,"d-mean",sep=""),"Fst_WC","Th1","Th2","Th3")
resxd[1:nb.conf,1]<-vec.2.vary # see at script start

# Filling up resxd with 3 theoretical expectations  (see 5.3 in the User Manual for formulas of Th1, Th2 and Th3)
for (r in 1:nb.conf) {
resxd[r,which(colnames(resxd)=="Th1")]<-(1/(1+4*N*resxd[r,1]))
resxd[r,which(colnames(resxd)=="Th2")]<-(1/(1+4*N*resxd[r,1]*((dem.nb*dem.nb)/((dem.nb-1)*(dem.nb-1)))))
resxd[r,which(colnames(resxd)=="Th3")]<-(1/(1+4*N*mu*(dem.nb/(dem.nb-1))+4*N*resxd[r,1]*((dem.nb*dem.nb)/((dem.nb-1)*(dem.nb-1)))))
}

# Filling up resxd with Mean Gstm and Gstcorm from gMetapop, using the last 100 generations
nbgen<-100  
for (r in 1:nb.conf) {   #nb.conf=21  r<-1
  wdir.simu<-paste(wdir,"/simu",r,sep="")    # should work on both wind and linux OS, make sure that the wdir path is updated at the script start
  setwd(wdir.simu)                           # type getwd() in R console to check working folder
  result<-read.table(file="res1_per_gen_2.txt",header=T,sep=";") # the "2" in res1_per_gen_2.txt and in  "res1_sample_2_genepop_neutral_..." below
                                                                 # correspond to the second set of Output stats for gen 9901 to 10000
  result<-as.matrix(result)
  resxd[r,which(colnames(resxd)==paste("Gst-",dem.nb,"d-mean",sep=""))]<-mean(result[,which(colnames(result)=="Gstm")])
  resxd[r,which(colnames(resxd)==paste("Gstcor-",dem.nb,"d-mean",sep=""))]<-mean(result[,which(colnames(result)=="Gstcorm")])
}  


# idem with computed Fst Weir and Cockerham  using Genepop sample files  (this can take up to 10 min in Win OS)
 setwd(wdir)
 for (r in 1:nb.conf) {   # r=1    getwd()
  FstWCGen<-matrix(nrow=nbgen,ncol=1)
    for (i in 9901:10000){  #i<-9901 and 10000 ad hoc i range here for this particular test, could be parameterized
    namein<-paste("simu",r,"/","res1_sample_2_genepop_neutral_",i,".txt",sep="")
    nameout<-paste("simu",r,"/","resFstWC_",i,sep="")
    resFstWC<-fastDivPart(infile = namein, outfile = NULL, gp = 3, pairwise = FALSE, fst = TRUE,
    bs_locus = FALSE, bs_pairwise = FALSE, boots = 0, plot = FALSE, para = FALSE)
    FstWCGen[i-9900,1]<-resFstWC$estimate[dim(resFstWC$estimate)[1],which(colnames(resFstWC$estimate)=="Fst_WC")]
    }
  resxd[r,which(colnames(resxd)=="Fst_WC")]<-mean(FstWCGen[1:nbgen,1],na.rm=TRUE)
 }
resxd
write.table(resxd,paste("res",dem.nb,"d.txt",sep=""),quote=FALSE,col.names=T,row.names=F,sep=";")  

## Computing correlations  (can be done independently, using the saved resxd df))
res<-read.table(file=paste("res",dem.nb,"d.txt",sep=""), header=T,sep=";",strip.white=T, fill=T)
corxd<-round(cor(res[,-1],  method = "pearson", use = "complete.obs"),4)
#cor.test(res[,"Th1"],res[,"Th3"],alternative = "two.sided",method = "pearson") # exact = NULL, conf.level = 0.95, continuity = FALSE, ...)
for (i in 2:6) { #  i<-2
  for (j in (i+1):7) {
   pval<-cor.test(res[,i],res[,j],alternative = "two.sided",method = "pearson")
   corxd[i-1,j-1]<-pval$p.value
  }
}
#write.table(corxd,"cor2d.txt",quote=FALSE,col.names=T,row.names=F,sep=";")   
write.table(corxd,paste("cor",dem.nb,"d.txt",sep=""),quote=FALSE,col.names=T,row.names=F,sep=";")   
                   

##  #D) Plots of Fst statistics as  a function of migration rates   (can be performed separately from the saved resxd df)
##   re-organing resxd
res<-read.table(file=paste("res",dem.nb,"d.txt",sep=""), header=T,sep=";",strip.white=T, fill=T)
colnames(res)<-c("m","gM_Gst","gM_Gstcor","Fst_WC","Theoretical_1","Theoretical_2","Theoretical_3")
library(reshape2)
df.for.plot<-melt(res, id="m", variable.name = "Statistic",na.rm = FALSE, value.name = "Differentiation",
  factorsAsStrings = TRUE)
library(ggplot2)
ggplot(data=df.for.plot, aes(x = m, y = Differentiation, color = Statistic)) +
  geom_point( size=2) +   #shape=, alpha=1/2
  scale_color_manual(values = c("gM_Gst" = "red", "gM_Gstcor" = "blue", "Fst_WC" = "green", "Theoretical_1"= "black", "Theoretical_2"= "brown", "Theoretical_3"= "gray")) +
  theme_bw() +
  theme(panel.grid.major=element_blank(),legend.position="top")
