############################################################################
## gMetapop - Test 5.1 - prog to run from the GUI File/Custom plot option ##
############################################################################
# Pauline Garnier-G�r� & Fr�d�ric Austerlitz Jan 2019
# Test for strong Selection on genotypes
# plot for 2 scenarios together (additive and dominant, see folders test5.1/run-complete... and User Manual 5.5.1)
# of allele frequency trajectories (of favourable alleles at different loci in each scenario + neutral alleles (1 to 9 out of 10))
# This script needs to access to conf.txt in the working folder
# Usage example: in the GUI, option "File/Custom plot" then type command
# test5.1.plotFreq.r res1_freq_1.txt test5.sce12 0.01 3000
      # res1_freq_1.txt is the output frequency file given by gMetapop (compulsory argument in the script for custom plo
      # test5.sce12 = second arg always needed is the name for the png plot opened via the GUI, 
      # -> it can be changed, no extension needed)
      #  "0.01" for example is the average initial allele frequency at loci under selection used (optional argument added in the script)
      # 3000 is the nb of generations for visualizing only part of the simulations, optional argument, if none is given, the max nb is used
# --> see gMetapop User Manual 3.9.2 for more explanations on custom plots

# this command line can be used outside the GUI in a linux environment or under a DOS prompt.
# The legends in the plot below corresponds to 10% maximum difference between genotypes' fitness, this can be changed depending on
# similar scenarios tested.
# WARNING this script also uses the conf.txt corresponding to simulations, a conf.txt file produced automatically by the GUI
# so the user needs to be careful to keep the correct format if editing it

require(plyr)
# Define arguments for launching the Rscript from command line
cmd_args <- commandArgs(trailingOnly = TRUE)
result.file<-cmd_args[1]
plot.name<-cmd_args[2]
ini.sel.al.freq<-cmd_args[3]
nb.of.gen.on.plot<-cmd_args[4]

# Import gMetapop allele frequencies result file
res<-read.table(file=result.file, header=T,sep=";",strip.white=T, fill=T)

#Get selected loci from conf.txt
conf <- scan(file="conf.txt",what=character(0), sep="\n", quiet=TRUE)
extract.conf.num.last<-function(x) as.numeric( strsplit(x,split=" ")[[1]][length(strsplit(x,split=" ")[[1]])] )
extract.conf.char<-function(x)  strsplit(x,split=" ")[[1]][length(strsplit(x,split=" ")[[1]])]

nb.pop<-extract.conf.num.last(conf[3])
# extract nb of loci under selection/QTL and their allele nb
 if (extract.conf.char(grep('Kind of sel', conf, value=TRUE))!="n") {
    # get nb of selected loci
     seline<-grep('Selected nuclear', conf, value=TRUE)
     selloc<-as.numeric(strsplit( strsplit(seline,split=":")[[1]][2] , split=" ")[[1]])
     selloc.nona<-selloc[which(is.na(selloc)==F)]
     nb.sel<-sum( selloc.nona )

    # extract data frame or matrix with selected alleles a2 under positive selection here
    col.a2<-grep("a2",colnames(res), value=TRUE)
    res.a2<-res[,c("Generation","Pop",col.a2)]
    res.a2.sel<-res.a2[,c("Generation","Pop",colnames(res.a2)[which(selloc.nona==1)+2]) ]

    # extract data frame with neutral alleles
      lneu.nb<-paste("l",which(selloc.nona==0),"a",sep="")
      allneu.nb<-NULL
      for (i in 1:length(lneu.nb) ) {
      lneu.al<-grep(lneu.nb[i],names(res)) ;  allneu.nb<-c(allneu.nb,lneu.al)
      }
     res.neu1<-res[,c("Generation","Pop",names(res)[allneu.nb])] # names(res.neu)
     res.neu<-res.neu1[,-which(names(res.neu1) %in% grep("a10",colnames(res.neu1), value=TRUE))]  #  removing 10th alleles at each neutral locus
 }

#Opening  png plot device --> png file processed by GUI afterwards
 png(filename=paste(plot.name,".png",sep=""),unit = "cm", width = 17, height = 15 , res = 300)
# pdf(file=paste(plot.name,".pdf",sep=""))  # pdf(file="fig.pdf", width = 7, height = 6 ) # alternative to get an additional pdf plot

###############################
## Plot all allele trajectories
ylim.maxbound<-1 
ylim.minbound<-0 

if (is.na(nb.of.gen.on.plot)==T) nbgen<-max(res$Generation) else nbgen<-as.numeric(nb.of.gen.on.plot)

if (length(names(res.neu))!=0 ) {
al1 <-colnames(res.neu)[3]
plot(res.neu$Generation[which(res.neu$Pop==1)],res.neu[which(res.neu$Pop==1),al1], col = "lightgrey", ylab="allele frequency changes", xlab="Generations", ylim=c(ylim.minbound,ylim.maxbound),
  xlim=c(0,nbgen), type = "l" )  # one pop, one locus
# other loci, only 1 pop ( more can be added), still 10 cod1 loci /replicates --> enough lines representative of neutral evolution in plot
  for (al in colnames(res.neu)[-c(1,2)]) {
#  for (i in 1:nb.pop) {
   lines(res.neu$Generation[which(res.neu$Pop==1)],res.neu[which(res.neu$Pop==1),al], col="lightgrey", lwd = 1 )
#  }
  }       # head(res.neu)
}

### plot loci in res.sel (= loci potentially under selection), since some loci have been set with no fitness differences
### in the configuration chosen for test 5, allele frequencies are extracted only for loci actually submitted to selection in
### particular populations
res.sel<-res.a2.sel # res.sel is the allele freq matrix for a2 the allele under positive selection, see above
for (loc in colnames(res.sel)[-c(1,2)][1:10]) { #First 10 selected loci, same fitness values across first 5 pop, additive case
  for (i in 1:5) {
   lines(res.sel$Generation[which(res.sel$Pop==i)],res.sel[which(res.sel$Pop==i),loc], col="red", lwd = 1.5 )
  }
}
for (loc in colnames(res.sel)[-c(1,2)][11:20]) { # other  next 10 loci, same fitness values across pop 6 to 10, dominant case
  for (i in 6:10) {
   lines(res.sel$Generation[which(res.sel$Pop==i)],res.sel[which(res.sel$Pop==i),loc], col="blue", lwd = 1.5 )
  }
}

### Adding Theoretical curves
ngen = nbgen
valres = matrix(0,ngen+1,4)
p0=ini.sel.al.freq    #ini.sel.al.freq <-0.00001
s = 0.1  # 10% max fitness differences between genotypes
w11 = 1
w12 = c(1-s/2,1)
w22 = 1-s

valres[1,]=c(0,as.numeric(p0),as.numeric(p0),as.numeric(p0))

for (gen in 2:(ngen+1)) {  #gen<-2
	valres[gen,1]=gen-1
	for (typ in 1:2) { # typ= type of heterozygote (ie defines the scenarios)
		p = valres[gen-1,typ+1] # initial pop freq of A selected allele
		q = 1-p
		w1 = p*w11 + q*w12[typ] # fitness of Ax genotypes --> A allele
		w = p*p*w11 + 2*p*q*w12[typ] + q*q*w22  # fitness total pop
		valres[gen,typ+1] = p*w1/w  # new frequency of A allele based on its relative fitness
	}
}

lines(valres[,1],valres[,2], col="darkred", lwd=4, lty=2)
lines(valres[,1],valres[,3], col = "cyan", lwd=4, lty=2)

legend("right",lwd=c(2,4,2,4,3),lty=c(1,2,1,2,1), legend=c("additive", "additive (theory)","dominant 10%","dominant (theory)",
"neutral"), col=c("red","darkred","blue","cyan","lightgrey"), inset=0.05,bg="white",box.lty=0) # bty="n"
dev.off()