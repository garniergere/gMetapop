############################################
## gMetapop- Test 5.1.2
############################################
# script for plotting average persistence times in simple drift scenarios.
# possible to launch as Custom Plot in the GUI
# see gMetapop User Manual Chapter 5 Test 5.1.2
# Pauline Garnier-G�r� and Fr�d�ric Austerlitz Nov 2019

require(plyr)
# Define arguments for launching the Rscript from command line
cmd_args <- commandArgs(trailingOnly = TRUE)
result.file<-cmd_args[1] # result.file<-"res1_freq_1.txt" define argument 1 as the res per gen filename
plot.name<-cmd_args[2] # plot.name<-"custom.test1" second arg for custom plot is always the name for the png plot opened via the GUI
                       # see png() below = compulsory line for the GUI to manage the plot. Otherwise the plot might be in the working folder but
                       # not visible via the GUI.

nbloc = 50  # for the 50 cytos loci corresponding to 50 independent replicates

# Import gMetapop allele frequencies result files  (1 locus per replicate)

for (i in 1:nbloc) {
  res.file<-paste("res",i,"_freq_1.txt",sep="")
  if (i==1) {
    res<-read.table(file=result.file, header=T,sep=";",strip.white=T, fill=T)
    res<-res[,1:3]
  }
  else {
    res2 <-read.table(file=res.file, header=T,sep=";",strip.white=T, fill=T)
    colnames(res2)[3]<-paste(colnames(res)[3],i,sep="_")  # only one allele needed since biallelic loci
    res <-cbind(res,res2[,3,drop=F])
  }
}

newdon<-res # newdon is the freq file in the correct format with only the first allele across loci
nbpop<-40     # nb of populations starting with a # initial allele frequency
# Import population intial frequencies popfinit2.txt for 40 pop
popfinit2<-read.table(file="popfinit2.txt", header=F,sep="\t",dec=".",strip.white=T)
colnames(popfinit2)<-c("pop","initf")

# Creating matrix to fill with first generation at which there is fixation
fixtime.simul<-matrix(NA,nbpop,nbloc)
locfixlist<-NULL
for (i in 1:nbloc) {
  locfixlist<-c(locfixlist,paste("locfix",i,sep=""))
  }
colnames(fixtime.simul)<-locfixlist
# merging with popfinit2 with 40 pop and 50 loci
fixtime.sim<-cbind(popfinit2,fixtime.simul); fixtime.sim<-as.matrix(fixtime.sim)

 for (i in 1:nbloc) { # loop on loci  i<-25
   for (p in 1:nbpop) { # loop across pop (i.e. one initial allele frequency value)  p<-20
      fix.i.pop.p<-newdon[which(newdon[,2]==p),c(1,2+i)] # extracting all p pop data
      fixtime.sim[p,2+i]<-min(rbind(fix.i.pop.p[which(fix.i.pop.p[,2]==0),],fix.i.pop.p[which(fix.i.pop.p[,2]==1),])[,1]) # min of Generation times where allele fixed
      if (length(fixtime.sim)==0) fixtime.sim[p,2+i]<-NA   # tested with case no fixation OK
   }
 }
maxfix<- aaply(fixtime.sim[,-c(1:2)],1,function(x) max(x,na.rm=T)) # search for max across each row vector (initial allele freq),
quan75<-quantile(maxfix,probs=0.75,na.rm=T)
quan90<-quantile(maxfix,probs=0.90,na.rm=T)
#     0%     25%     50%     75%    100%
#  61.00  731.75  895.00 1386.00 9059.00

# Opening  png plot device --> png file processed by gMetapop GUI afterwards
png(filename=paste(plot.name,".png",sep=""),unit = "cm", width = 20, height = 18 , res = 600)  # next version gM

# Theoretical curve data
Ne<-100 ; p0<-data.frame(seq(0,1,0.0001))
fixtim<-function(N,p) {
 fixt<-(-2*N*((1-p)*log(1-p)+p*log(p)));  return(fixt)
}
curve.fix<-data.frame(p0,fixtim(Ne,p0)); colnames(curve.fix)<-c("p0","fixt")
plot(curve.fix$p0,curve.fix$fixt, col="red",pch=16,cex=0.1, xlab="Initial frequency",
                          ylab="Persistence times across loci (averages ",xlim=c(0.0,1.0),ylim=c(0.0,round(600,0)) )
# Completing  theoretical curve  with simulated data
fixtime<-as.data.frame(fixtime.sim) #names(fixtime.sim)
meanfix<-apply(fixtime[,-c(1,2)],1,mean,na.rm = TRUE); fixtimef<-cbind(fixtime,meanfix) # compute and merge mean across loci
# adding means across loci (big squares)
points(fixtimef$initf,fixtimef$meanfix, col="red",lwd=3,pch=15,cex=0.8)
#adding all individual replicate loci
cl <- colors()
plotcol50<-sample(cl,nbloc,replace = FALSE, prob = NULL)
for (i in 1:length(plotcol50)) {
         c.i<-plotcol50[i]    
         locfix.i<-fixtimef[,i+2] 
         points(fixtimef$initf,locfix.i, col=c.i,lwd=3,pch=16,cex=0.4)
        }
dev.off()
