############################################
## gMetapop- Test 4  - 2D-SS
############################################
# script for plotting the 2D Stepping Stone simulation results (see User Manual Chapter 5 Tests 4 )
# Fr�d�ric Austerlitz & Pauline Garnier-G�r� Jan 2019
# See script test4_1D.custom.plot.Xrep.4Arg for additional information on a similar script for 1D-Stepping Stone case

require(diveRsity)
# Arguments for Rscript in command line
cmd_args <- commandArgs(trailingOnly = TRUE)
result.file<-cmd_args[1] #  for example result.file is "output.txt" in the command line
plot.name<-cmd_args[2]   # plot.name<-"custom" second arg for custom plot is always the name for the png plot
rep.nb<-cmd_args[3]      # 3rd Arg is the number of replicates being processed
gen<-cmd_args[4]         # 4th Arg is a time or generation step at which sample files are available

## --> Usage: please type in the custom plot window from the GUI (see the other script for the 1D case
## test4_1D.custom.plot.Xrep.4Arg.R script for more explanations):
##     test4_2D.custom.plot.Xrep.4Arg.R output.txt custom10 10 10000

nind = 1000
tabval=matrix(0,as.numeric(rep.nb),2)
listdist.tot<-NULL    # initialize vectors to plot all rep together
listFstlin.tot<-NULL

for (rep in 1:as.numeric(rep.nb) ) {
#rep<-1
	filename = paste("res",rep,"_sample_1_genepop_neutral_",as.numeric(gen),".txt",sep="")
  res = fastDivPart(infile = filename, outfile = "test4.SS2D", fst = T, pairwise = T)
	matFst = res$pairwise$thetaWC
	npop = dim(matFst)[1]
	ncomp = npop*(npop-1)/2
	ncolo = sqrt(npop)
	listFst=matrix(0,ncomp)
	listdist = matrix (0, ncomp)

	c=1
	for (pop1 in 1:(npop-1))   {
		for (pop2 in (pop1+1):npop) {
			listFst[c]=matFst[pop2,pop1]
			col1 = pop1 %% ncolo
			lin1 = pop1 %/% ncolo
			col2 = pop2 %% ncolo
			lin2 = pop2 %/% ncolo
			listdist[c]=log(sqrt((lin1-lin2)^2+(col1-col2)^2))
			c=c+1
		}
 }

	listFstlin = listFst/(1-listFst)
	b = lm(listFstlin  ~ listdist)$coefficients[2]
	attributes(b) = NULL
	nsigma2 = 1/(4*pi*b)
	sigma2 = nsigma2/nind
	tabval[rep,1] = b
	tabval[rep,2] = sigma2

listdist.tot<-rbind(listdist.tot,listdist)       # merging vectors of pairwise pop ditances values to plot with Fst/(1-Fst) val across rep
listFstlin.tot<-rbind(listFstlin.tot,listFstlin)  # merging  pairwise Fst estimates across replicates

} # end loop across rep

write.table(cbind(listdist.tot,listFstlin.tot),result.file,sep=" ")

  # pdf plot --> here various arguments can appear in the plot name if needed
    pdf(file=paste(plot.name,".",rep.nb,".pdf",sep=""), width = 7, height = 6 )
		plot(listdist.tot, listFstlin.tot, xlab = "Log(Distance)", ylab="Fst/(1-Fst)")
		dev.off()

  # png plot also opened with the GUI  - those lines should no be modified otherwise the GUI can't open the png plot
  # the plot.name argument is chosen by the user in the custom plot window line
    png(paste(plot.name,".png",sep=""),unit = "cm", width = 20, height = 18 , res = 600)
    plot(listdist.tot, listFstlin.tot, xlab = "Log(Distance)", ylab="Fst/(1-Fst)")
		dev.off()


write.table(tabval, file = "table_res_wc.txt")
meansigma = mean(tabval[,2])
sprintf("mean sigma: %g", meansigma)
