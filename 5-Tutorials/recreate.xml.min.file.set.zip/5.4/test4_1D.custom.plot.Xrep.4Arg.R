############################################
## gMetapop- Test 4- 1D-SS
############################################
# script for plotting 1D Stepping Stone simulation results (see User Manual Chapter 5 Tests 4) , using 4 possible arguments
# Fr�d�ric Austerlitz & Pauline Garnier-G�r� Nov 2019

require(diveRsity)
# Arguments for Rscript in command line
cmd_args <- commandArgs(trailingOnly = TRUE)
result.file<-cmd_args[1]#  result.file<-"output.txt" (the string "output.txt" is just an example, the only constraint is that this argument
                        # is not empty. In this script, it just correspond to the result file merging replicates for the plot and that is output
                        # but it is not really needed for the plot.
plot.name<-cmd_args[2]  # plot.name<-"custom" (name example)-> the second arg is always a name provided for the png plot opened via the GUI
rep.nb<-cmd_args[3]     # here the 3rd Arg is the rep.nb ie the number of replicates processed for one plot, which correspond to the output files
                        # which have been produced and need to be in the working folder
gen<-cmd_args[4]        # here the 4th Arg is simply one the step at which sample files are available, based on options clicked in the Output Tab
                        # of the GUI --> see in the run-1D-10pop working folder: sample files have been produced at step 5000 (same as generation here)
                        # for the first 10 replicates for the sake of the example.

## --> Usage: please type in the custom plot window from the GUI:
##     test4_1D.custom.plot.Xrep.4Arg.R output.txt custom50 50 10000
                         # the 4 arguments after the R script can be changed
                         # "output.txt" here is just the name given to the output from the X=Fst/(1-Fst),Y=pairwise pop distance vectors
                         # in the script, it can be modified.
                         # custom50 is the name of the plot merging 50 replicates
                         # 50 is the number of replicates used (i.e. the number of sample file processed) which can be below
                         # the max number of replicates chosen in the run tab.
                         # 10000 is the generation step for this particular plot

nind = 1000        # population equilibrium size
tabval=matrix(0,as.numeric(rep.nb),2) # initializing tabval
listdist.tot<-NULL    # initialize vectors to plot all rep together
listFstlin.tot<-NULL


for (rep in 1:as.numeric(rep.nb) ) {
#rep<-1
	filename = paste("res",rep,"_sample_1_genepop_neutral_",as.numeric(gen),".txt",sep="")

  res = fastDivPart(infile = filename, outfile = "test4.SS", fst = T, pairwise = T)
	matFst = res$pairwise$thetaWC
	npop = dim(matFst)[1]
	ncomp = npop*(npop-1)/2
	listFst=matrix(0,ncomp)
	listdist = matrix (0, ncomp)

	c=1
	for (pop1 in 1:(npop-1)) {    # added one set of brackets
		for (pop2 in (pop1+1):npop) {
			listFst[c]=matFst[pop2,pop1]
			listdist[c]=pop2-pop1
			c=c+1
		}
}
	listFstlin = listFst/(1-listFst)
	b = lm(listFstlin  ~ listdist)$coefficients[2]
	attributes(b) = NULL
	nsigma2 = 1/(4*b)
	sigma2 = nsigma2/nind
	tabval[rep,1] = b
	tabval[rep,2] = sigma2

listdist.tot<-rbind(listdist.tot,listdist)       # merging vectors of pairwise pop ditances values to plot with Fst/(1-Fst) val across rep
listFstlin.tot<-rbind(listFstlin.tot,listFstlin)  # merging  pairwise Fst estimates across replicates

} # end loop across rep

write.table(cbind(listdist.tot,listFstlin.tot),result.file,sep=" ")
	
  # pdf plot --> here various arguments can appear in the plot name if needed
    pdf(file=paste(plot.name,".",rep.nb,".pdf",sep=""), width = 7, height = 6 )
		plot(listdist.tot, listFstlin.tot, xlab = "Distance", ylab="Fst/(1-Fst)")
		dev.off()

  # png plot is also opened with the GUI  - the 3 lines below should no be modified otherwise the GUI can't open the png plot
  # the plot.name argument is chosen by the user in the custom plot window line
    png(paste(plot.name,".png",sep=""),unit = "cm", width = 20, height = 18 , res = 600)
    plot(listdist.tot, listFstlin.tot, xlab = "Distance", ylab="Fst/(1-Fst)")
		dev.off()

 
write.table(tabval, file = "table_res_wc.txt")
meansigma = mean(tabval[,2])
sprintf("mean sigma: %g", meansigma)
