############################################
## gMetapop- Tests 4 - 1D-SS
############################################
# script for plotting 1D Stepping Stone simulations results files (see User Manual Chapter 5 Tests 4 )
# Fr�d�ric Austerlitz & Pauline Garnier-G�r� Nov 2019

require(diveRsity)
# Arguments for Rscript in command line
cmd_args <- commandArgs(trailingOnly = TRUE)
result.file<-cmd_args[1] # for example "res1_sample_1_genepop_neutral_10000.txt" = argument 1 of the Custom plot command line
                         # to write in the pop-up windows in the GUI: here it is a sample file in a GENEPOP format located
                         # in the working folder, "10000" in the file name is the generation number at which the plot is made, it can be changed
                         # if the simulation requests output at different time steps
plot.name<-cmd_args[2]   # plot.name is for example "custom.1" = second argument of the command line, which is always the name
                         # for the plot to be opened via the GUI (using a *.png format)

# Usage example in custom plot window for example:
#   test4_1D.custom.plot.1rep.only.2Arg.R res1_sample_1_genepop_neutral_10000.txt custom.1

nind = 1000
rep.nb = 1
tabval=matrix(0,rep.nb,2)
gen<-10000

# NB: any parameter above can be used as an additional argument in a custom plot script
# --> SEE lines 9 to 13 above for the use of arguments and test4_1D.custom.plot.Xrep.4Arg.R script for an example  with more arguments

  filename1<-result.file      # first argument after name of Rscript in GUI window / Custom plot
  res = fastDivPart(infile = filename1, outfile = "test4.SS.txt", fst = T, pairwise = T)
	matFst = res$pairwise$thetaWC     # updated for R ver > 3.3.3
	npop = dim(matFst)[1]
	ncomp = npop*(npop-1)/2
	listFst=matrix(0,ncomp)
	listdist = matrix (0, ncomp)

	c=1
	for (pop1 in 1:(npop-1))  {
		for (pop2 in (pop1+1):npop) {
			listFst[c]=matFst[pop2,pop1]
			listdist[c]=pop2-pop1
			c=c+1
		}
	}
	listFstlin = listFst/(1-listFst)
	b = lm(listFstlin  ~ listdist)$coefficients[2]
	attributes(b) = NULL
	nsigma2 = 1/(4*b)
	sigma2 = nsigma2/nind
	tabval[rep.nb,1] = b
	tabval[rep.nb,2] = sigma2
	
  # pdf plot
    pdf(file=paste(plot.name,".pdf",sep=""))
		plot(listdist, listFstlin, xlab = "Distance", ylab="Fst/(1-Fst)")
		dev.off()
  # png plot also opened with the GUI
    png(filename=paste(plot.name,".png",sep=""),unit = "cm", width = 20, height = 18 , res = 600)
    plot(listdist, listFstlin, xlab = "Distance", ylab="Fst/(1-Fst)")
		dev.off()

write.table(tabval, file = "table_res_wc.txt")
meansigma = mean(tabval[,2])
sprintf("mean sigma: %g", meansigma)
