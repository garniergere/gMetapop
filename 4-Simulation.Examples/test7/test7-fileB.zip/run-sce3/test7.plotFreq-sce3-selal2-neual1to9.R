#############################################################
## gMetapop - Test 7 - prog to run from Custom plot option ##
#############################################################
# Pauline Garnier-G�r� & Fr�d�ric Austerlitz Jan 2019
# Test 7 = Strong Selection on genotypes
# plot for 3 scenarios (additive, dominant, recessive) together (see folder run-complete & Chapter 5 test 7 User Manual)
# of allele frequency trajectories (favourable allele in each scenario + neutral alleles (2 to 10))
# Usage: File Menu in the GUI, option "Custom plot" then type command
# test7.etc...(this script).R res1_freq_1.txt test7.sce123 0.00001
                     # res1_freq_1.txt is the output frequency file given by gMetapop
                     # "test7.sce3" is the plot.name can be changed
                     #  0.00001 is the average initial allele frequency at loci under selection
                     # in simulations with initial fixed loci when using a mutation rate of 10-05  (used as additional argument in the script here)
# --> see gMetapop User Manual 3.9.2 for more explanations on custom plots
# this command line can be used outside the GUI
## The legends in the plot below corresponds to 10% maximum difference between genotypes' fitness, can be changed


require(plyr)
# Define arguments for launching the Rscript from command line
cmd_args <- commandArgs(trailingOnly = TRUE)
result.file<-cmd_args[1] # result.file<-"res1_freq_1.txt"
plot.name<-cmd_args[2] # plot.name<-"test7.sce123" second arg for custom plot is always the name for the png plot opened via the GUI
ini.sel.al.freq<-cmd_args[3] # ini.sel.al.freq<-0.00001 third argument of custom plot command line, needs to be consistent with simulation configuration

# Import gMetapop allele frequencies result file
res<-read.table(file=result.file, header=T,sep=";",strip.white=T, fill=T)  # head(res)

### Get selected loci from conf.txt
conf <- scan(file="conf.txt",what=character(0), sep="\n", quiet=TRUE)
extract.conf.num.last<-function(x) as.numeric( strsplit(x,split=" ")[[1]][length(strsplit(x,split=" ")[[1]])] )
extract.conf.char<-function(x)  strsplit(x,split=" ")[[1]][length(strsplit(x,split=" ")[[1]])]
nb.pop<-extract.conf.num.last(conf[3])
## extract nb of loci under selection/QTL and their allele nb (WARNING Plot script works for a conf.txt produced automatically by the GUI
## not one that has been edited)
 if (extract.conf.char(conf[(23 + nb.pop)])!="n") { # if selection type is "t" for trait or "g" for genotypic
    # get nb of selected loci
    seline<-conf[(25+nb.pop)]
    selloc<-as.numeric(strsplit( strsplit(seline,split=":")[[1]][2] , split=" ")[[1]])
    selloc.nona<- selloc[which(is.na(selloc)==F)]
    nb.sel<-sum( selloc.nona)

    # extract data frame or matrix with selected alleles a2 under positive selection here
    col.a2<-grep("a2",colnames(res), value=TRUE)
    res.a2<-res[,c("Generation","Pop",col.a2)]
    res.a2.sel<-res.a2[,c("Generation","Pop",colnames(res.a2)[which(selloc.nona==1)+2]) ]  #head(res.a2.sel)

    # extract data frame with neutral alleles
      lneu.nb<-paste("l",which(selloc.nona==0),"a",sep="")   #[1] "l1a"  "l6a"  "l7a"  "l11a" "l16a" "l18a" "l19a" "l21a" "l25a" "l28a"
      allneu.nb<-NULL
      for (i in 1:length(lneu.nb) ) {
      lneu.al<-grep(lneu.nb[i],names(res)) ;  allneu.nb<-c(allneu.nb,lneu.al)
      }
     res.neu1<-res[,c("Generation","Pop",names(res)[allneu.nb])] # names(res.neu)
     res.neu<-res.neu1[,-which(names(res.neu1) %in% grep("a10",colnames(res.neu1), value=TRUE))]  #  removing 10th alleles at each neutral locus
 }

### Opening  png plot device --> png file processed by GUI afterwards
 png(filename=paste(plot.name,".png",sep=""),unit = "cm", width = 17, height = 15 , res = 300)
# pdf(file=paste(plot.name,".pdf",sep=""))  # pdf(file="fig.pdf", width = 7, height = 6 )

###############################
## Plot all allele trajectories
ylim.maxbound<-1 
ylim.minbound<-0 
nbgen<-max(res$Generation)

if (length(names(res.neu))!=0 ) {
al1 <-colnames(res.neu)[3]
plot(res.neu$Generation[which(res.neu$Pop==1)],res.neu[which(res.neu$Pop==1),al1], col = "lightgrey", ylab="allele frequency changes", xlab="Generations", ylim=c(ylim.minbound,ylim.maxbound),
  xlim=c(0,nbgen), type = "l" )  # one pop, one locus
# other loci, only 1 pop ( more can be added), still 10 cod1 loci /replicates --> enough lines representative of neutral evolution in plot
  for (al in colnames(res.neu)[-c(1,2)]) {
#  for (i in 1:nb.pop) {
   lines(res.neu$Generation[which(res.neu$Pop==1)],res.neu[which(res.neu$Pop==1),al], col="lightgrey", lwd = 1 )
#  }
  }       # head(res.neu)
}

### plot loci in res.sel (loci under selection) (but here some loci under selection in some pop won't be in other pop
### Warning here given the configuration chosen, allele frequencies were extracted for loci actually submitted to selection, given
###  the particular genetic map below used in simulations
### Selected nuclear  loci (0=neutral, 1=selected) : 0 1 1 1 1 0 0 1 1 1 0 1 1 1 1 0 1 0 0 1 0 1 1 1 0 1 1 0 1 1 1 1 1 1 1 1 1 1 1 1
### since some loci potentially under selection were not assigned fitness differences among genotypes depending on the scenario
res.sel<-res.a2.sel # res.sel if the allele freq matrix for a2 the allele under positive selection, see above
for (loc in colnames(res.sel)[-c(1,2)][1:10]) { #First 10 selected loci, same fitness values across 5 pop,
  for (i in 1:5) {
   lines(res.sel$Generation[which(res.sel$Pop==i)],res.sel[which(res.sel$Pop==i),loc], col="green", lwd = 1.5 )
  }
}

### Adding Theoretical case
ngen = nbgen
valres = matrix(0,ngen+1,4)
p0=ini.sel.al.freq    #ini.sel.al.freq <-0.00001
s = 0.1  # 10% max fitness differences between genotypes
w11 = 1
w12 = c(1-s/2,1,1-s) # in turn additive , dominant & recessive case as in simulations
w22 = 1-s

valres[1,]=c(0,as.numeric(p0),as.numeric(p0),as.numeric(p0))

for (gen in 2:(ngen+1)) {  #gen<-2
	valres[gen,1]=gen-1
	for (typ in 1:3) { #typ<-3 typ is type of heterozygote (ie defines the scenarios)
		p = valres[gen-1,typ+1] # initial pop freq of A selected allele
		q = 1-p
		w1 = p*w11 + q*w12[typ] # fitness of Ax genotypes --> A allele
		w = p*p*w11 + 2*p*q*w12[typ] + q*q*w22  # fitness total pop
		valres[gen,typ+1] = p*w1/w  # new frequency of A allele based on its relative fitness
	}
}

#lines(valres[,1],valres[,2], col="darkred", lwd=4, lty=2)
#lines(valres[,1],valres[,3], col = "cyan", lwd=4, lty=2)
lines(valres[,1],valres[,4], col = "darkgreen", lwd=4, lty=2)

legend("center", bty="n", lwd=c(2,4,3),lty=c(1,2,1), legend=c("recessive 10%","recessive (theory)","neutral"), col=c("green","darkgreen","lightgrey"))
dev.off()